package com.obsqura.Scripts;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.obsqura.constant.Constant;

public class TestBase {
	public static Properties prop = null;
	WebDriver driver;

	public static void testBase() {
		try {
			//// Below line creates an object of Properties called 'prop'
			prop = new Properties();
			// Below line creates an object of FileInputStream called 'ip'. Give the path of
			// the properties file which you have created
			FileInputStream ip = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources" + "/config.properties");
			// Below line of code will load the property file
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Parameters("browser")
	@BeforeTest
	public void setUp(String browser) throws Exception {

		testBase();
		String baseUrl = prop.getProperty("baseUrl");
		if (browser.equalsIgnoreCase(Constant.FIREFOXBROWSER)) {
			// Initializing the firefox driver (Gecko)
			System.setProperty(Constant.FIREFOXDRIVER, prop.getProperty("firefoxpath"));
			driver = new FirefoxDriver();
		} else if (browser.equalsIgnoreCase(Constant.CHROMEBROWSER)) {
			// Initialize the chrome driver
			System.setProperty(Constant.CHROMEDRIVER, prop.getProperty("chromepath"));
			driver = new ChromeDriver();
		} else {
			// If no browser passed throw exception
			throw new Exception(Constant.BROWSERNOTCORRECT);
		}

		driver.get(baseUrl);
	}

	@AfterMethod
	public void takeScreenShotOnFailure(ITestResult iTestResult) throws IOException {
		if (iTestResult.getStatus() == iTestResult.FAILURE) {
			takeScreenShotOnFailure(iTestResult.getName());

		}
	}

	public String takeScreenShotOnFailure(String name) throws IOException {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());

		// Take the screenshot
		File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		String destination = System.getProperty("user.dir") + "\\target\\" + name + dateName + ".png";

		File finalDestination = new File(destination);

		FileUtils.copyFile(source, finalDestination);
		return destination;
	}

	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}
