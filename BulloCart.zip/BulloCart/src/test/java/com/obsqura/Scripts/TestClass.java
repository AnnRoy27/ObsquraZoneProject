package com.obsqura.Scripts;

import org.testng.annotations.Test;

import com.obsqura.Utilities.ExcelUtilites;
import com.obsqura.constant.Constant;
import com.obsqura.pages.Home;
import com.obsqura.pages.Login;
import com.obsqura.pages.Product;
import com.obsqura.pages.Users;

import org.apache.bcel.classfile.ConstantClass;
import org.testng.Assert;

import java.io.IOException;

public class TestClass extends TestBase {

	Login objLogin;
	Home objhome;

	Product objProduct;
	Users objUsers;

	@Test(priority = 1)
	public void verifyLoginInvalidUserNameValidPassword() throws IOException {
		objLogin = new Login(driver);
		String invalidUsernameValidPassword = ExcelUtilites.getCellStringData(1, 0);
		int password = ExcelUtilites.getCellNumericData(1, 1);
		String password1 = String.valueOf(password);
		objLogin.loginToHomePage(invalidUsernameValidPassword, password1);
		objLogin.clickLogin();
		Assert.assertEquals(Constant.VALIDATIONERRORMESSAGE, objLogin.getErrorMessage());
	}

	@Test(priority = 6)
	public void verifyLogin() throws IOException {
		objLogin = new Login(driver);
		String username = ExcelUtilites.getCellStringData(0, 0);
		int password2 = ExcelUtilites.getCellNumericData(0, 1);
		String password1 = String.valueOf(password2);
		objLogin.setUserName(username);
		objLogin.setPassword(password1);
		objLogin.checkBox();
		objLogin.clickLogin();
		Assert.assertEquals(objLogin.getHomePageTitle(), Constant.HOMETITLE);
	}

	@Test(priority = 2)
	public void verifyLoginValidUserNameInvalidPassword() throws IOException {
		objLogin = new Login(driver);
		objLogin.clearUserNameAndPassword();
		String validUserName = ExcelUtilites.getCellStringData(2, 0);
		String invalidPassword = ExcelUtilites.getCellStringData(2, 1);
		objLogin.loginToHomePage(validUserName, invalidPassword);
		objLogin.clickLogin();
		Assert.assertEquals(Constant.VALIDATIONERRORMESSAGE, objLogin.getErrorMessage());
	}

	@Test(priority = 3)
	public void verifyWithLoginUserNameNoPassword() throws IOException {
		objLogin = new Login(driver);
		objLogin.clearUserNameAndPassword();
		String validUserName = ExcelUtilites.getCellStringData(2, 0);
		objLogin.setUserName(validUserName);
		objLogin.clickLogin();
		Assert.assertEquals(Constant.VALIDATIONERRORMESSAGE, objLogin.getErrorMessage());

	}

	@Test(priority = 4)
	public void verifyLoginWithPassWordNoUserName() throws IOException {
		objLogin = new Login(driver);
		objLogin.clearUserNameAndPassword();

		int passwordcorrect = ExcelUtilites.getCellNumericData(4, 1);
		String password = String.valueOf(passwordcorrect);

		objLogin.setPassword(password);
		objLogin.clickLogin();
		Assert.assertEquals(Constant.VALIDATIONERRORMESSAGE, objLogin.getErrorMessage());
	}

	@Test(priority = 5)
	public void verifyForgotPassword() {
		objLogin.clickForgotpassword();
		Assert.assertEquals(objLogin.getForgotPasswordTitle(), Constant.LOGINDEMOPOS);
	}

	@Test(priority = 7)
	public void verifyDisplayOfCalculator() {
		objhome = new Home(driver);
		objhome.endButton();
		objhome.clickCalculator();
		Assert.assertEquals(objhome.calculatorTitle(), Constant.CALCULATOR);

	}

	@Test(priority = 8)
	public void verifyAdditionOfTwoNumbers() {
		objhome = new Home(driver);
		objhome.additionOfTwoNumbers();
		Assert.assertEquals(objhome.calculatotText(), Constant.EXPECTEDCALCULATORTEXT);
	}

	@Test(priority = 9)
	public void verifyPosTerminal() {
		objhome = new Home(driver);
		objhome.posTerminal();
		Assert.assertEquals(objhome.posTitlle(), Constant.POSTERMINAL);
		objhome.PosTerminalBack();
	}

	@Test(priority = 10)
	public void verifyProductPage() {
		objProduct = new Product(driver);
		objProduct.productPage();
		Assert.assertEquals(objProduct.productTypeText(), Constant.EXPECTEDPRODUCTTYPE);
	}

	@Test(priority = 11)
	public void verifyListProductPage() {
		objProduct = new Product(driver);
		objProduct.productPage();
		Assert.assertEquals(objProduct.productTypeText(), Constant.EXPECTEDPRODUCTTYPE);
	}

	@Test(priority = 12)
	public void verifyProductType() {
		objProduct = new Product(driver);
		objProduct.productType();
		Assert.assertEquals(objProduct.productTypeText(), Constant.EXPECTEDPRODUCTTYPE);
	}

	@Test(priority = 13)
	public void VerifyCategoryField() {
		objProduct = new Product(driver);
		objProduct.category();
		Assert.assertEquals(objProduct.textCategory(), Constant.EXPECTEDCATEGORYTEXT);
	}

	@Test(priority = 14)
	public void verifyunitField() {
		objProduct = new Product(driver);
		objProduct.unitfield();
		Assert.assertEquals(objProduct.unitText(), Constant.UNITFIELDTEXT);
	}

	@Test(priority = 15)
	public void verifyTaxField() {
		objProduct = new Product(driver);
		objProduct.taxField();
		Assert.assertEquals(objProduct.taxFieldText(), Constant.TAXFIELD);
	}

	@Test(priority = 16)
	public void verifybrandField() {
		objProduct = new Product(driver);
		objProduct.brandField();
		Assert.assertEquals(objProduct.brandFieldText(), Constant.BRANDFIELD);
	}

	@Test(priority = 17)
	public void verifyAddProductField() {
		objProduct = new Product(driver);
		objProduct.addProduct();
		Assert.assertEquals(objProduct.addProductText(), Constant.TEXTPRODUCTFIELD);
	}

	@Test(priority = 18)
	public void verifyalertQuantity() {
		objProduct = new Product(driver);
		objProduct.alertQuantity();
		Assert.assertEquals(objProduct.alertQuantutyText(), Constant.QUALITYALERT);
	}

	@Test(priority = 19)
	public void verifyBrandFieldInAddProduct() {
		objProduct = new Product(driver);
		objProduct.brandFieldInAddProduct();
		objProduct.addNameToBrandName();
		objProduct.saveBrandNameAdded();
		Assert.assertEquals(objProduct.brandFIELDInAddProductText(), Constant.BRANDFIELDADDPRODUCT);
	}

	@Test(priority = 20)
	public void verifyPrintLabelsPage() {
		objProduct = new Product(driver);
		objProduct.printLables();
		Assert.assertEquals(objProduct.printLabelText(), Constant.PRINTLABLES);
	}

}