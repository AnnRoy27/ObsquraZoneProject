package com.obsqura.Utilities;

import java.io.FileInputStream;

import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtilites {

	public static String getCellStringData(int RowNum, int ColNum) throws IOException

	{
		FileInputStream f = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources" + "/Book1.xlsx");
		XSSFWorkbook w = new XSSFWorkbook(f);
		Sheet sh = w.getSheet("sheet1");
		return sh.getRow(RowNum).getCell(ColNum).getStringCellValue();

	}

	public static int getCellNumericData(int RowNum, int ColNum) throws IOException

	{
		FileInputStream f = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources" + "/Book1.xlsx");
		XSSFWorkbook w = new XSSFWorkbook(f);
		Sheet sh = w.getSheet("sheet1");
		return (int) sh.getRow(RowNum).getCell(ColNum).getNumericCellValue();
	}
}
