package com.obsqura.Utilities;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageUtilities {
	public WebElement waitForElementTobeVisible(WebDriver driver, WebElement elementToBeLoaded, int Time) {
		WebDriverWait wait = new WebDriverWait(driver, Time);
		WebElement element = wait.until(ExpectedConditions.visibilityOf(elementToBeLoaded));
		return element;
	}

	public WebElement waitForElementTobeClickable(WebDriver driver, WebElement elementToBeLoaded, int Time) {
		WebDriverWait wait = new WebDriverWait(driver, Time);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(elementToBeLoaded));
		return element;
	}

	public Alert waitForAlert(WebDriver driver, int Time) {
		WebDriverWait wait = new WebDriverWait(driver, Time);
		Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		return alert;
	}

	public void hitenter(WebDriver driver, WebElement element) {
		// Retrieve WebElemnt to perform mouse hover
		element.sendKeys(Keys.ENTER);
	}

	public void sendTestUsingMouseActions(WebDriver driver, WebElement element, String text) {
		// Retrieve WebElemnt to perform mouse hover

		Actions action = new Actions(driver);
		action.sendKeys(element, text).build().perform();

	}

	public void moveToElement(WebDriver driver, WebElement element) {
		// Retrieve WebElemnt to perform mouse hover

		Actions action = new Actions(driver);
		action.moveToElement(element).build().perform();

	}

	public void contextClick(WebDriver driver, WebElement element) {
		// Retrieve WebElemnt to perform mouse hover

		Actions action = new Actions(driver);
		action.moveToElement(element);
		action.contextClick().build().perform();
	}

	public void doubleClick(WebDriver driver, WebElement element) {
		// Retrieve WebElemnt to perform mouse hover

		Actions action = new Actions(driver);
		action.moveToElement(element);
		action.doubleClick();
} 
	

	
	
	
	public void sleep(long time) throws InterruptedException {
		Thread.sleep(time);
	}
}
