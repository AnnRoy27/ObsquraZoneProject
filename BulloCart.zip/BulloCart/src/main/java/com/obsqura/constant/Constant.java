package com.obsqura.constant;

public class Constant {
	public static final String CHROMEDRIVER = "webdriver.chrome.driver";
	public static final String VALIDATIONERRORMESSAGE = "These credentials do not match our records.";
	public static final String BROWSERNOTCORRECT = "Browser is not correct";
	public static final String FIREFOXDRIVER = "webdriver.gecko.driver";
	public static final String CHROMEBROWSER = "chrome";
	public static final String FIREFOXBROWSER = "firefox";
	public static final String LOGINDEMOPOS = "Login - Demo POS";
	public static final String CALCULATOR = "Calculator";
	public static final String POSTERMINAL = "POS Terminal";
	public static final String HOMETITLE = "Home - Reobeen HHC";
	public static final String EXPECTEDCALCULATORTEXT = "null";
	public static final String EXPECTEDUSERPAGETITLE = "Users";
	public static final String EXPECTEDPRODUCTTYPE = "Products";
	public static final String EXPECTEDCATEGORYTEXT = "Category:";
	public static final String UNITFIELDTEXT = "Unit:";
	public static final String TAXFIELD = "Tax:";
	public static final String BRANDFIELD = "Brand:";
	public static final String TEXTPRODUCTFIELD = "Product Name:*";
	public static final String QUALITYALERT = "Alert quantity:*";
	public static final String BRANDFIELDADDPRODUCT = "Brand:";
	public static final String PRINTLABLES = "Brand:";
	public static final String USERS="All users&quot";
	public static final String ADDUSERS="Add user";
	public static final String SURNAMEPREFIX="Prefix";
	public static final String FIRSTNAMETITLE="First Name:*";
	public static final String LASTNAMETITLE="Last Name";
	public static final String EMAILTITLE="Email:*";
	public static final String USERNAMETITLE="Username:";
	public static final String PASSWORDTITLE="Password:*";
	public static final String CONFROMPASSWORDTITLE="Confirm Password:*";
	public static final String USERMANAGEMENTOPTIOCLASSTITLEN="User Management";
	public static final String SUPPLIERSPAGETITLE="Suppliers - Reobeen HHC";
	public static final String SHOWENTRY25="25";
	public static final String EXPECTEDADDNEWCONTACT="Add a new contact";
	public static final String CONTACTTYPE="Add a new contact";
	

	

}
