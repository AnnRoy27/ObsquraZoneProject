package com.obsqura.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Product {
	WebDriver driver;
	@FindBy(xpath = "//span[text()='Products']")
	WebElement productpage;
	@FindBy(xpath = "//selection[@class='content-header']")
	WebElement productTitle;
	@FindBy(xpath = "//a[@href='https://buffalocart.com/demo/billing/public/products']")
	WebElement listProductpage;
	@FindBy(xpath = "//selection[@class='content-header']")
	WebElement listpageText;
	@FindBy(xpath = "//*[@id='collapseFilter']/div/div[1]/div/span/span[1]/span")
	WebElement text;
	@FindBy(xpath = "//*[@id='tour_step5_menu']/span[1]")
	WebElement textproductList;
	@FindBy(xpath = "//*[@id='select2-product_list_filter_category_id-container']")
	WebElement category;
	@FindBy(xpath = "//label[text()='Category:']")
	WebElement textcategory;
	@FindBy(xpath = "//*[@id=\'select2-product_list_filter_unit_id-container\']")
	WebElement unit;
	@FindBy(xpath = "//label[text()='Unit:']")
	WebElement unittext;
	@FindBy(xpath = "//*[@id=\'select2-product_list_filter_tax_id-container\']")
	WebElement taxField;
	@FindBy(xpath = "//label[text()='Tax:']")
	WebElement taxFieldText;
	@FindBy(xpath = "//*[@id='select2-product_list_filter_brand_id-container']")
	WebElement brandField;
	@FindBy(xpath = "//label[text()='Brand:']")
	WebElement brandFieldText;
	@FindBy(xpath = "//a[@class='btn btn-primary pull-right']")
	WebElement addProduct;
	@FindBy(id = "name")
	WebElement name;
	@FindBy(xpath = "//label[text()='Product Name:*']")
	WebElement nameText;
	@FindBy(id = "name")
	WebElement brandFieldInAddProduct;
	@FindBy(xpath = "//input[text()='Brand name']")
	WebElement addNameToBrandName;
	@FindBy(xpath = "//button[@type='submit']")
	WebElement saveBrandNameAdded;
	@FindBy(xpath = "//label[text()='Brand:']")
	WebElement textOnBrand;
	@FindBy(xpath = "//*[@id='alert_quantity']")
	WebElement alertQuantity;
	@FindBy(xpath = "//label[text()='Alert quantity:*']")
	WebElement alertQuantityText;
	@FindBy(xpath = "//a[@href='https://buffalocart.com/demo/billing/public/labels/show']")
	WebElement printLabels;
	@FindBy(xpath = "/html/body/div[2]/div[1]/section[1]/h1/text()")
	WebElement printLabelText;

	public Product(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void productPage() {
		productpage.click();
		listProductpage.click();
	}

	public String listPageTitle() {
		String actual = listpageText.getText();
		return actual;
	}

	public void productType() {
		text.click();
	}

	public String productTypeText() {
		return textproductList.getText();
	}

	public void category() {
		category.click();
	}

	public String textCategory() {
		return textcategory.getText();
	}

	public void unitfield() {
		unit.click();
	}

	public String unitText() {
		return unittext.getText();
	}

	public void taxField() {
		taxField.click();
	}

	public String taxFieldText() {
		return taxFieldText.getText();
	}

	public void brandField() {
		brandField.click();
	}

	public String brandFieldText() {
		return brandFieldText.getText();
	}

	public void addProduct() {
		addProduct.click();
		name.sendKeys("sweets");
	}

	public String addProductText() {
		return nameText.getText();
	}

	public void brandFieldInAddProduct() {
		brandFieldInAddProduct.click();

	}

	public void addNameToBrandName() {
		addNameToBrandName.sendKeys("ganesh");
	}

	public void saveBrandNameAdded() {
		saveBrandNameAdded.click();
		driver.navigate().back();
	}

	public void alertQuantity() {
		alertQuantity.click();
		alertQuantity.sendKeys("23");

	}

	public void brandText() {
		textOnBrand.getText();
	}

	public String alertQuantutyText() {
		return alertQuantityText.getText();
	}

	public void printLables() {
		printLabels.click();
		printLabels.sendKeys("nataraj pencil");

	}

	public String brandFIELDInAddProductText() {
		return brandFieldInAddProduct.getText();
	}

	public String printLabelText() {
		return printLabels.getText();
	}
}
