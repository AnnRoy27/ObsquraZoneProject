package com.obsqura.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Users {
	WebDriver driver;
	@FindBy(xpath = "//h3[@class='box-title']")
	WebElement UsersText;
	@FindBy(xpath = "//i[@class='fa fa-plus']")
	WebElement UserAddButton;
	@FindBy(xpath = "//section[@class='content-header']/h1")
	WebElement AddUser;
	@FindBy(xpath = "//input[@id='surname']")
	WebElement SurName;
	@FindBy(xpath = "//label[@for='surname']")
	WebElement SurNamePrefix;
	@FindBy(xpath = "//input[@id= 'first_name']")
	WebElement FirstName;
	@FindBy(xpath = "//label[@for='first_name']")
	WebElement FirstNameField;
	@FindBy(xpath = "//input[@id= 'last_name']")
	WebElement LastName;
	@FindBy(xpath = "//label[@for='last_name']")
	WebElement LastNameField;
	@FindBy(xpath = "//input[@id= 'email']")
	WebElement Email;
	@FindBy(xpath = "//label[@for='email']")
	WebElement EmailField;
	@FindBy(xpath = "//input[@id='username']")
	WebElement UserUserName;
	@FindBy(xpath = "//label[@for='username']")
	WebElement UserNameField;
	@FindBy(xpath = "//input[@id='password']")
	WebElement UserPassword;
	@FindBy(xpath = "//label[@for='password']")
	WebElement UserPasswordField;
	@FindBy(xpath = "//input[@id='confirm_password']")
	WebElement UserConfromPassword;
	@FindBy(xpath = "//label[@for='confirm_password']")
	WebElement UserConfromPasswordField;

	public Users(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String getUserText() {

		return UsersText.getText();
	}

	public void getUserAddButton() {
		UserAddButton.click();
	}

	public String getAddUser() {
		return AddUser.getText();
	}

	public void getSurName(String strsurname) {
		SurName.sendKeys(strsurname);
	}

	public void UserSurname(String strsurname) {
		// Fill user name
		this.getSurName(strsurname);
	}

	public String getsurnamePrefixText() {
		return SurNamePrefix.getText();
	}

	public void getFirstName(String strfirstname) {
		FirstName.sendKeys(strfirstname);
	}

	public void UserFirstName(String strfirstname) {
		this.getFirstName(strfirstname);
	}

	public String getFirstNameTitle() {
		return FirstNameField.getText();
	}

	public void getLastName(String strlastname) {
		LastName.sendKeys(strlastname);
	}

	public void UserLastName(String strlastname) {
		this.getLastName(strlastname);
	}

	public String getLastNameTitle() {
		return LastNameField.getText();
	}

	public void getEmail(String stremail) {
		Email.sendKeys(stremail);
	}

}
