package com.obsqura.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Home {
	WebDriver driver;

	@FindBy(xpath = "//button[text()='End tour']")
	WebElement endButton;
	@FindBy(xpath = "//i[@class='fa fa-calculator fa-lg']")
	WebElement calculator;
	@FindBy(xpath = "//h3[@class='popover-title']")
	WebElement calculatorTitle;
	@FindBy(xpath = "//a[@href='https://buffalocart.com/demo/billing/public/pos/create']")
	WebElement posTerminal;
	@FindBy(xpath = "//h3[@class='box-title']")
	WebElement posTitle;
	@FindBy(id="5")
	WebElement calculatorValue1;
	@FindBy(id="2")
	WebElement calculatorValue2;
	@FindBy(id="+")
	WebElement addition;
	@FindBy(id="equals")
	WebElement equals;
	@FindBy(id="result")
	WebElement calculatorText;
	@FindBy(id="allClear")
	WebElement ClearCalculatorvalues;
	@FindBy(xpath = "//i[@class='fa fa-angle-left pull-right']")
	WebElement UserManagement;
	@FindBy(xpath = "//i[@class='fa fa-user']")
	WebElement User;


	public Home(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void endButton() {
		endButton.click();
	}

	public void clickCalculator() {
		calculator.click();
	}

	public String calculatorTitle() {

		return calculatorTitle.getText();
	}

	public void posTerminal() {
		posTerminal.click();
	}
	public void PosTerminalBack()
	{
		driver.navigate().back();
	}

	public String posTitlle() {
		String actual = driver.getTitle();
		return posTitle.getText();
	}
	public void calculatorValue1()
	{
		calculatorValue1.click();
		//calculatorValue2.click();
	}
	public void calculatorValue2()
	{
		calculatorValue2.click();
	}
	public void addition()
	{
		addition.click();
	}
	public void equals()
	{
		equals.click();
	}
	public void clearcalculatorvalue()
	{
		ClearCalculatorvalues.click();
	}
	public void additionOfTwoNumbers()
	{
		this.calculatorValue1.click();
		this.addition.click();
		this.calculatorValue2.click();
		this.equals.click();
		this.ClearCalculatorvalues.click();
	}
	public String calculatotText()
	{
		return calculator.getAttribute("value");
	}
	public void getUserManagement() {
		UserManagement.click();
	}

	public void getUser() {
		User.click();
	}

	
}
