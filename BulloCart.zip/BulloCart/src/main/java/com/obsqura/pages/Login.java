package com.obsqura.pages;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
	WebDriver driver;
	@FindBy(id = "username")
	WebElement username;
	@FindBy(id = "password")
	WebElement pass;
	@FindBy(xpath = "/html/body/div[3]/div/div/div/div[2]/form/div[4]/div/button")
	WebElement login;
	@FindBy(xpath = "//strong[text()='These credentials do not match our records.']")
	WebElement errorMessage;

	@FindBy(xpath = "//input[@name='remember']")
	WebElement checkbox;
	@FindBy(xpath = "//a[@class='btn btn-link']")
	WebElement forgotpassword;

	public Login(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void setUserName(String strUserName) {

		username.sendKeys(strUserName);

	}

	public String getHomePageTitle() {
		String title = driver.getTitle();
		return title;
	}

	public void setPassword(String password) {

		pass.sendKeys(password);

	}

	public String getErrorMessage() {
		return errorMessage.getText();

	}

	public void clickLogin() {
		login.click();

	}

	public void userNameClear() {
		username.clear();
	}

	public void passWordClear() {
		pass.clear();
	}

	public void checkBox() {
		checkbox.click();
	}

	public String getForgotPasswordTitle() {
		String actual = driver.getTitle();
		return actual;
	}

	public void clickForgotpassword() {

		forgotpassword.click();
		driver.navigate().back();

	}

	public void loginToHomePage(String strUserName, String strPasword) {
		// Fill user name
		this.setUserName(strUserName);
		// Fill password
		this.setPassword(strPasword);
		// Click Login button
		this.clickLogin();
	}

	public void clearUserNameAndPassword() {
		this.username.clear();
		this.pass.clear();
	}
}
