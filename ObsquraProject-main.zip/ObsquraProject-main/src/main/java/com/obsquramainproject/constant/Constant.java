package com.obsquramainproject.constant;

public class Constant {
public static final String logintitle = "Login: Mercury Tourss" ;
public static int timeout = 60;
public static final String username = "admin";
public static final String password = "123456";
public static final String propertyfilepath = System.getProperty("user.dir") + "\\properties\\config.properties";
public static final String walkincustomerdetails =System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelTestData\\WalkInCustomerDetails.xlsx";
public static final String addnewpurchase =System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelTestData\\Purchasepage.xlsx";
public static final String customereditdetails =System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelTestData\\CustomerEditDetails.xlsx";
public static final String customerdetails =System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelTestData\\CustomerDetails.xlsx";
public static final String newuserdetails =System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelTestData\\NewUser.xlsx";
public static final String newsalesdetails =System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelTestData\\NewSalesDetails.xlsx";
public static final String ProductDetails =System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelTestData\\ProductDetailsAdd.xlsx";
public static final String productpagedetails =System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelTestData\\ProductPageDetails.xlsx";
public static final String quantitydetails =System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelTestData\\QuantityEdit.xlsx";
public static final String logindetails =System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelTestData\\RegisterLogin.xlsx";
}


